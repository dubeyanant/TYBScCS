public class Cc {
    public static void main(String[] args) {
        for (int i = 1; i < 16; i++) {
            for (int j = 1; j < 11; j++) {
                System.out.println(i + " * " + j + " = " + i * j);
            }
            System.out.println();
        }
    }

}
