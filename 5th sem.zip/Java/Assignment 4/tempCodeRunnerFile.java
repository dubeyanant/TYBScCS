for (i = 0; i < n; i++) { // storing items in respective objects
        // s = br.readLine();
        // StringTokenizer t = new StringTokenizer(s, space);
        // String id = new String(t.nextToken());
        // String name = new String(t.nextToken());
        // String price = new String(t.nextToken());
        // String qty = new String(t.nextToken());

        // it[i] = new item(id, name, price, qty);
        // }