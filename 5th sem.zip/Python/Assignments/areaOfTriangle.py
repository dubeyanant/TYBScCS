''' area of triangle'''

b = int(input("Enter the base of the traingle: "))
h = int(input("Enter the height of the traingle: "))

a = (0.5) * b * h

print("Area of the triangle: ", a)