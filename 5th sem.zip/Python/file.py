import os
#f = open("test.txt")
#for x in f:
 #       print(x)
#f.write("The first line of the file")
os.remove("test.txt")